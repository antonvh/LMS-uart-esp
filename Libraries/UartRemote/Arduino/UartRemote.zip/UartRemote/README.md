# UartRemote library for Arduino

This is work in progress. The current library supports a limited number of types, compared to the MicroPython UartRemote library.
